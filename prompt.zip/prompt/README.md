# Prompts

Plain-text copies of every prompt the scorer sends to the model, exported from the code.
**These files are reference copies. The code still reads the Python strings** in
`src/candidate_fit/prompt.py` and `src/candidate_fit/optimized.py`, so editing a file here does not
change a run until the code is changed to load it.

Each prompt is a `system_prompt.txt` plus a `user_prompt_template.txt`. `{PLACEHOLDERS}` are filled
in at run time. Labels, row ids and dataset metadata are never sent.

## A. `single_pass/` - one call does everything

| File | Purpose |
|---|---|
| `system_prompt.txt` | Extracts requirements, skills, domains and roles, then scores the pair 0-10 (0-3 No Fit, 4-6 Potential Fit, 7-10 Good Fit). Minified JSON output. |
| `user_prompt_template.txt` | JD and resume text. |

## B. `three_prompt/` - extraction split from scoring

The resume and the JD are each analysed once (independently, so results can be cached and reused
across pairs); the scorer then sees only the two structured analyses.

| Step | System prompt | Input | Output |
|---|---|---|---|
| 1 | `1_resume_extraction_system_prompt.txt` | resume text | primary role, domains and subdomains, every work experience (dates, responsibilities, skills, achievements), total years, highest education, certifications |
| 2 | `2_jd_extraction_system_prompt.txt` | JD text | job title, role family, seniority, domains and subdomains, all skills (mandatory/preferred, importance), top 3-5 critical skills, minimum years, education, certifications, other requirements |
| 3 | `3_relevancy_scoring_system_prompt.txt` | both extractions (JSON) | per-skill, per-requirement and per-role match status plus dimension scores; the application derives the final 0-10 score and label and applies caps for unmet mandatory requirements |
